

PRINT RESUME

#  Revision Tracker

####  Goal: Revise each topic at least 3 times

| Topic                  | Times Revised ✅ | Planned 📌 | Last Revised 📆 | Revision Checkboxes                   |
| ---------------------- | --------------- | ---------- | --------------- | ------------------------------------- |
| Exception Handling     | 1               | 3          | 2025-06-23      | { X } ,  {  } ,  {  }                 |
| Collections            | 1               | 3          | 2025-06-23      | { X } ,  {  } ,  {  }                 |
| oops                   | 1               | 5          | 2025-06-23      | { X } ,  {  } ,  {  } , {  } ,   {  } |
| Multi threading        | 1               | 4          | 2025-06-23      | {  X } ,  {  } ,  {  } , {  }         |
| Memory management      | 1               | 3          | 2025-06-23      | { X  } ,  {  } ,  {  }                |
| JDBC                   | 1               | 3          | 2025-06-23      | { X } ,  {  } ,  {  }                 |
| JDK , JRE, JVM         | 1               | 3          | 2025-06-23      | { X } ,  {  } ,  {  }                 |
| IV q from Essentials   | 1               | 4          | 2025-06-24      | { X } ,  {  } ,  {  } , {  }          |
| Console APP            | 0               | 3          |                 |                                       |
| Previous Revision List | 1               | 4          | 2025-06-24      | { X } ,  {  } ,  {  } , {   }         |
| RME Notes              | 1               | 3          | 2025-06-25      | { X } ,  {  } ,  {  }                 |
| Siva IV Feedbacks      | 1               | 3          | 2025-06-26      | {  X  } ,  {  } ,  {  }               |
| DBMS                   | 1               | 4          | 2025-06-26      | { X  } ,  {  } ,  {  },  {  }         |
| SQL                    | 0               | 4          |                 | {  } ,  {  } ,  {  },  {  }           |
| Namaste JavaScript     | 0               | 3          |                 | {  } ,  {  } ,  {  }                  |
| JAVASCRIPT PRIMER      | 0               | 3          |                 | {  } ,  {  } ,  {  }                  |
| MERN QA                | 0               | 3          |                 | {  } ,  {  } ,  {  }                  |
| DESIGN Principle       | 0               | 3          |                 | {  } ,  {  } ,  {  }                  |

---

## 🧾 Notes
- ✅ Tick one box *every time* you revise the topic.
- ⏳ Update **Last Revised** with each session.
- 🏁 Goal: Don’t learn new until **3 checkmarks**.

