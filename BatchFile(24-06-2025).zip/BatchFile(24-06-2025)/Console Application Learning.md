

##  Summary of Format Fixes

| Format Code | Meaning                           | Example Output |
| ----------- | --------------------------------- | -------------- |
| `%d`        | Integer                           | `200`          |
| `%f`        | Float/double (default 6 decimals) | `200.000000`   |
| `%.2f`      | Float with 2 decimal places       | `200.00`       |
| `%-7.2f`    | Left-aligned, 7-width float       | `200.00`       |
| %-s         | String                            | abd            |


```java
   char pickUpPoint = scn.next().charAt(0);
```


A Singleton ensures that **only one object** of a class is **created in memory** during the application's lifetime, and provides a **global access point** to that object.

Use Singleton when:

| Situation                             | Why Singleton Helps                       |
| ------------------------------------- | ----------------------------------------- |
| You need **only one instance**        | Prevents accidental duplicates            |
| You need **shared state**             | Centralized data storage                  |
| You want a **global manager/service** | All parts of your app use the same object |
| You need **lazy initialization**      | Don’t create until it’s needed            |

|Real-World Object|Why Singleton Applies|
|---|---|
|**Database Connection Pool**|Only one shared pool manages DB connections|
|**Print Spooler**|One queue manages all print jobs|
|**Train Control System**|One system controls tracks/scheduling|

```java
public class MySingleton {

    // Step 1: private static instance
    private static MySingleton instance;

    // Step 2: private constructor
    private MySingleton() {
        // prevent instantiation
    }

    // Step 3: public static getter
    public static MySingleton getInstance() {
        if (instance == null) {
            instance = new MySingleton();  // create once
        }
        return instance;
    }

    // Example method
    public void showMessage() {
        System.out.println("I'm the only instance!");
    }
}

```


How to use ?

```Java
MySingleton s1 = MySingleton.getInstance();
MySingleton s2 = MySingleton.getInstance();

System.out.println(s1 == s2); // true — both point to same object

```


### 24-06-25

- After initializing the single ton we need to add data 
- Avoid typo
- if you cant get the instance globally declare global and get instance at the main function