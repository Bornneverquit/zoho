
Top Questions to practice:

https://chatgpt.com/s/t_685974d7c8988191bc3245aeae474fb4


**Q: What is an aggregate function in SQL?**

Aggregate functions perform **calculations over a set of rows** and return a **single value result**, such as totals, averages, or maximums.

Common examples include: `SUM()`, `AVG()`, `MAX()`, `MIN()`, and `COUNT()`.

These functions are often used with **`GROUP BY`** to perform aggregations per group and can be filtered using `WHERE` or `CASE WHEN` for conditional sums or counts.




```sql

 SELECT  MAX(salary) as SecondHighestSalary from Employee where salary < ( SELECT MAX(salary) from Employee );
```


```sql
  
SELECT ( 
SELECT distinct salary from Employee order by salary desc limit 1 offset 1) 
as SecondHighestSalary;

```


Let's understand `LIMIT` and `OFFSET` — they’re used together often in SQL, especially in **pagination** and **top-N queries**.

####  **1. What is `LIMIT` in SQL?**

### 🔹 Definition:

`LIMIT` is used to **restrict the number of rows** returned by a query.

### 📘 Syntax:

```sql
SELECT * FROM Employee LIMIT 5;
```


**Result:** Returns the **first 5 rows** from the `Employee` table.


####  **2. What is `OFFSET` in SQL?**

### 🔹 Definition:

`OFFSET` is used to **skip a number of rows** before starting to return results.

##### 📘 Syntax:

```sql
SELECT * FROM Employee LIMIT 5 OFFSET 2;
```



**Result:**

- Skips first 2 rows
    
- Then returns the **next 5 rows**
    


####  Common Use Case: Pagination

For example, if you're showing 10 records per page:

| Page | Query                |
| ---- | -------------------- |
| 1    | `LIMIT 10 OFFSET 0`  |
| 2    | `LIMIT 10 OFFSET 10` |
| 3    | `LIMIT 10 OFFSET 20` |


#####  1. **What is `DISTINCT` in SQL?**

##### 🔹 **Definition:**

`DISTINCT` is used to **remove duplicate values** from the result of a `SELECT` query.


##### 📘 Syntax:

```sql
SELECT DISTINCT column_name FROM table_name;
```


#####  Example:


`SELECT DISTINCT salary FROM Employee;`

#####  Use Cases:

- When you only want **unique values**
    
- Avoiding **duplicates** in dropdowns, reports, filters

    
#####  2. **What is `ORDER BY` in SQL?**

##### 🔹 **Definition:**

`ORDER BY` is used to **sort the result set** by one or more columns, either in:

- `ASC` (ascending – default)
    
- `DESC` (descending)
    

##### 📘 Syntax:

```sql
SELECT column1, column2 FROM table_name ORDER BY column1 [ASC|DESC], column2 [ASC|DESC];

```

```sql
SELECT * FROM Employee ORDER BY salary DESC;
```

##### 🔄 You Can Use Them Together

```sql
SELECT DISTINCT salary FROM Employee ORDER BY salary DESC;
```


- Removes duplicates
    
- Then sorts in descending order
    

#####  Notes

|Concept|Rule|
|---|---|
|`DISTINCT`|Affects the **rows returned**, not how they’re sorted|
|`ORDER BY`|Does not remove duplicates — only reorders rows|


#####  1. `NOT IN`

##### 🔹 **Definition**:

`NOT IN` filters out rows whose values **exist in a subquery or list**.

##### 📘 Syntax:

`SELECT * FROM Employee WHERE dept_id NOT IN (1, 2, 3);`

##### 🧠 Example with Subquery:

`SELECT name FROM Employee WHERE id NOT IN (SELECT manager_id FROM Employee);`

✅ Returns employees who **are not managers**.