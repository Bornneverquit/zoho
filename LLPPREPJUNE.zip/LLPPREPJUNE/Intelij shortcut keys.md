
`alt + insert` -- insert a class

`sout` -- System.out.println

`shift + alt + down key` - for moving down

`ctrl + D` Duplicating the line