
|Component|Code Sample / Idea|
|---|---|
|`ReservationOperations` (interface)|`bookTicket()`, `cancelTicket()`, `viewSeats()`|
|`RailwayReservation` (class)|Implements all logic + maintains seat list|
|`ReservationApp` (main class)|Scanner menu for input/output|

when a object was initialized the left side we need to mention the interface and the right-side as a Class that implements 

When You open a Scanner you need to close it also you can use try block inside the scanner that automatically close the scanner when the try block ends

Interface only have a contract the method signatures

The balance was declared as a private because it provides the data integrity we cannot access directly to the variable 

 Why did you declare `balance` as `private`? What is **encapsulation**?

- Checks: If you understand data protection.
    
- Expected Answer: To prevent external modification. We access it using public methods only, ensuring data integrity.


