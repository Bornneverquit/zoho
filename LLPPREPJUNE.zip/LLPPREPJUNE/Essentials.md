

#  Exception Handling 

---

## 🔹 What is Exception Handling?

> Exception handling in Java is a **mechanism to manage runtime errors**, allowing the program to continue its normal flow even when unexpected situations occur.

- Prevents abrupt termination
- Makes the code more robust and maintainable

---

## 🔹 Compile-Time vs Run-Time Errors

| Category         | Compile-Time Error                        | Run-Time Error                             |
|------------------|--------------------------------------------|--------------------------------------------|
| When it occurs   | During code compilation                   | During program execution                   |
| Examples         | Missing semicolon, undeclared variable     | Division by zero, null pointer access      |
| Catchable?       | ❌ Cannot be caught                        | ✅ Can be caught with try-catch            |
| Stops program?   | ✅ Prevents compilation                    | ❌ Can be handled to prevent crashing      |

>  *Compile-time is like spell-check before sending an email. Run-time is like crashing after clicking “Send”.*

---

## 🔹 Common Exception Types (Runtime)

- `ArithmeticException` → e.g. `10 / 0`
- `NullPointerException` → e.g. `obj.length()`
- `IllegalArgumentException`
- `NumberFormatException` → e.g. `Integer.parseInt("abc")`
- `ArrayIndexOutOfBoundsException`

---

## 🔹 try-catch-finally Syntax

```java
try {
    // risky code
} catch (ExceptionType e) {
    // handle it
} finally {
    // always runs (cleanup)
}
```


###  Notes:

- You can have **multiple catch blocks** for different exception types.
    
- The `finally` block **always executes**, even if there is a `return`, `break`, or another exception.
    

---

## 🔹 Checked vs Unchecked Exceptions

| Type        | Must Handle?            | Examples                                      |
| ----------- | ----------------------- | --------------------------------------------- |
| ✅ Checked   | Yes (compiler enforced) | `IOException`, `SQLException`                 |
| ❌ Unchecked | No (runtime only)       | `NullPointerException`, `ArithmeticException` |

> 🎯 **Checked = compile-time enforcement**  
> 🎯 **Unchecked = runtime failure** (subclass of `RuntimeException`)

> **Analogy:** Checked exceptions are like required paperwork before boarding a flight. Unchecked exceptions are like turbulence in mid-air.

---

## 🔹 Custom Exception Example

java

`class MyCustomException extends Exception {     public MyCustomException(String msg) {         super(msg);     } }`

- Extend `Exception` → **checked exception**
    
- Extend `RuntimeException` → **unchecked exception**
    

---

## 🔹 throws Keyword (Exception Propagation)

java


`void riskyMethod() throws IOException {     // caller must handle or declare }`

- Used to pass the responsibility to the method caller.
    
- Only applicable to **checked exceptions**.
    
- If a method doesn’t catch a checked exception, it **must declare it using `throws`**.
    

---

## 🔹 Exception Class Hierarchy


                  `Throwable    
                       /      \  
                     Error     Exception
                                     /      \ 
           Checked Exceptions   Unchecked (RuntimeException)`

### 🔸 Key Points:

- **`Error`**: Critical system failures (e.g., `OutOfMemoryError`) → do **not** handle in normal application code.
    
- **`Exception`**: Intended for recoverable issues caused by application logic.
    

---

## 🔹 Tip Summary

✅ Know the flow of `try-catch-finally`  
✅ Understand checked vs unchecked clearly  
✅ Be able to give examples of both  
✅ Show how to write a custom exception  
✅ Explain `throws` vs `try-catch` handling  
✅ Mention that `finally` always runs, even with `return` or exceptions  
✅ Draw or describe the exception hierarchy clearly




#  Collections 

---

 Java Collections is a Framework it have a many inbuilt class that are collectively gived as a package 

one of the major advantage is we can use the common add function for push and remove for most of the data structures 


Collections was majorly seprated in 4 ways 

List Interface - have arrayList , stack, arrays , Linked list List interface have a seperate property and behaviours 

Interface cannot be initiated directly

Collections have a interface called Iterator 

### 🔹 What is the Collections Framework?

> **Analogy:** Think of the Collections Framework as a **Swiss Army knife** of data structures — all neatly packed into one package (`java.util`). Whether you need a bag, list, queue, or map — it’s there, ready to be reused.

- **"Framework"**: A standardized architecture of **interfaces + classes**.
    
- Comes with **algorithms (like sorting)**, **interfaces**, and **data structure implementations**.
    
- Provides **consistency** across data types via common methods like `add()`, `remove()`, `iterator()`, `contains()`.

## Terminology Confusion Cleared

### 1. `Collection` vs `Collections`

|Term|What it is|Analogy|
|---|---|---|
|`Collection`|**Interface** (super interface of List, Set, Queue)|Like a master blueprint for containers|
|`Collections`|**Utility class** with static methods|Like a toolbox with helper tools (e.g. sort, reverse, shuffle)|

Collection (interface)
  ├── List       -> Ordered, allows duplicates
  ├── Set        -> No duplicates
  └── Queue      -> FIFO behavior


### `List` Interface Overview

> **Analogy:** Think of a **List** as a dynamic, resizable **shopping list** — you can add, remove, or access items by position.

- Preserves **insertion order**
    
- Allows **duplicates**
    
- Elements accessible via **index**
    

**Common Implementations:**

- `ArrayList` – fast random access, slow inserts/deletes in middle
    
- `LinkedList` – fast inserts/deletes, slow random access
    
- `Stack` – LIFO
    
- `Vector` – legacy thread-safe version of ArrayList


### Interfaces Cannot Be Instantiated

> Interfaces are like **contracts**. You can’t use a contract directly — you need a **class that implements it**.

java

CopyEdit

`List<String> list = new ArrayList<>(); // ✅ List<String> list = new List<>();      // ❌ Error`